#ifndef LISTPRODUCTS_H
#define LISTPRODUCTS_H


struct t_product {
    int ID; 
    char Name[128]; 
    double Price; 
    int Quantity;
} ;

#endif