#ifndef UTIL_H_
#define UTIL_H_

#include <string.h>
#include <stdio.h>

void trim(char *);
void clear_buffer();

#endif
