#ifndef PROBLEM1_H
#define PROBLEM1_H

#define BUFF 128

void first_return();
void second_return();
void third_return();
void fourth_return();
void fifth_return ();
void sixth_return ();
void seventh_return ();
void eighth_return ();
void nineth_return ();
void tenth_return ();

#endif