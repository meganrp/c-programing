#ifndef DYNAMICARRAY_H
#define DYNAMICARRAY_H

#define BUFF 128

typedef struct {
    double *data;
    int size;
} dynamic_array_t; 


#endif